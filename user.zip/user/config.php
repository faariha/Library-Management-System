<?php
session_start();

define('GOOGLE_CLIENT_ID', '511110742912-boc3f51ve91nith10656gjs8td6ql0q0.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URL', 'http://localhost/LMS2/index.php');

define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '1234');
define('DB_NAME', 'lms');
define('DB_USER_TBL', 'users');

if(!session_id()){
    session_start();
}

// require_once 





// require_once __DIR__.'/vendor/autoload.php';

// $google_client->setClientId(GOOGLE_CLIENT_ID);

// $google_client->setClientSecret(GOOGLE_CLIENT_SECRET);

// $google_client->setRedirectUri(GOOGLE_REDIRECT_URL);

// $google_client->addScope('email');
// $google_client->addScope('profile');

?>
<?php
	 $server = 'localhost';
        $username = 'root';
        $password = '1234';
        $database = 'lms';
        $connection = new mysqli($server, $username, $password, $database, 3306) or die("not 
        connected");
	$query = "delete from authors where author_id = $_GET[aid]";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Author Deleted successfully...");
	window.location.href = "manage_author.php";
</script>
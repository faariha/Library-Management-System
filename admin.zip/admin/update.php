<?php
	 $server = 'localhost';
        $username = 'root';
        $password = '1234';
        $database = 'lms';
        $connection = new mysqli($server, $username, $password, $database, 3306) or die("not 
        connected");
	$query = "update admins set name = '$_POST[name]',email = '$_POST[email]',mobile = '$_POST[mobile]'";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Updated successfully...");
	window.location.href = "admin_dashboard.php";
</script>
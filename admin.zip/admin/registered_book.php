<?php
	 $server = 'localhost';
        $username = 'root';
        $password = '1234';
        $database = 'lms';
        $connection = new mysqli($server, $username, $password, $database, 3306) or die("not 
        connected");
	$book_count = 0;
	$query = "select count(*) as book_count from books";
	$query_run = mysqli_query($connection,$query);
	while ($row = mysqli_fetch_assoc($query_run)){
		$book_count = $row['book_count'];
	}
?>
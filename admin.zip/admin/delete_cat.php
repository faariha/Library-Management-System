<?php
	 $server = 'localhost';
        $username = 'root';
        $password = '1234';
        $database = 'lms';
        $connection = new mysqli($server, $username, $password, $database, 3306) or die("not 
        connected");
	$query = "delete from category where cat_id = $_GET[cid]";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Category Deleted successfully...");
	window.location.href = "manage_cat.php";
</script>